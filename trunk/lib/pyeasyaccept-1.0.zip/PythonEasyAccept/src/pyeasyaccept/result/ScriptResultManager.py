""" 
This class stores a test script execution result. Each script test execution result will
be stored in a ScriptResultManager object, thus, an instance of this class will 
have a set of Result objects.

@author: Gustavo Pereira
"""
from pyeasyaccept.commom.Configuration import Configuration
class ScriptResultManager:
    

    def __init__(self, scriptName):
        self.scriptName = scriptName
        self.notPassedTest = 0
        self.passedTests = 0
        self.numOfTests = 0
        self.__linesResult = dict()
        
    
    def getNumPassedTests(self):
        """
        This method returns the number of passed tests of the current script
        @return: the number of passed tests
        """
        return self.passedTests
    
    def getNumNotPassedTests(self):
        """
        This method returns the number of Not passed tests of the current script
        @return: the number of not passed tests
        """
        return self.notPassedTest
    
    def getScriptName(self):
        """
        This method returns the name of the current test script
        @return: the name of the test script
        """
        return self.scriptName
    
    def getNumTests(self):
        """
        This method returns the number of the total executed tests of the current script
        @return: the number of the total executed tests
        """
        return self.numOfTests

    def addResult(self, oneResult):
        """
        This method adds a Result object of the current test script
        @param oneResult: A Result object
        """
        if(oneResult.getTestLineStatus() == Configuration.SUCCESS_CODE):
            self.passedTests += 1
        else:
            self.notPassedTest += 1
            
        self.numOfTests += 1   
        self.__linesResult[oneResult.getLine()] = oneResult
          
    def getLineResult(self, line):
        """
        This method returns a test line Result object
        @param line: the test script line
        @return: the test result of the current test script line
        """      
        return self.__linesResult[line]  
    
    def getResults(self):
        """
        This method returns all the test results of the current test script
        @return: all the test results of the current test script
        """   
        return self.__linesResult
