""" 
This class contains a script's test line result. Each script's test line result will
be stored in a Result.

@author: Gustavo Pereira
"""
class Result:

    line = -1
    
    def __init__(self, command, lineStatus, lineResult):
        self.command = command
        self.lineStatus = lineStatus
        self.lineResult = lineResult
        self.exception = None
        self.errorMessage = ""
    

    def getCommand(self):
        """
        The command that originate the Result
        @return: The command name
        """
        return self.command
    
    def getTestLineStatus(self):
        """
        This method returns the test line status
        @return: The string code "PASSED" if the test passed. Otherwise, the method returns the string code "FAILURE"
        """
        return self.lineStatus
    
    def setLine(self, line):
        """
        This method sets the script line related to the Result object
        @param line: : A test script line 
        """
        self.line = line

    def getLine(self):  
        """
        This method returns the script line related with the Result object
        @return: The tested script line
        """
        return self.line;
    
    def getTestLineResult(self):
        """
        This method returns the test line result related with the Result object
        @return: The tested script line
        """
        return self.lineResult
    
    def addException(self, exception, errorMessage):
        """
        This method add an exception related to the Result object. The error message
        can be different of the original exception message.
        @param exception: The exception
        @param message: The exception message
        """
        self.exception = exception
        self.errorMessage = errorMessage
    
    def getErrorMessage(self):
        """
        This method returns the test line exception
        @return: The tested script line exception, if an exception has been occurred. None, otherwise.
        """
        return self.errorMessage    
    