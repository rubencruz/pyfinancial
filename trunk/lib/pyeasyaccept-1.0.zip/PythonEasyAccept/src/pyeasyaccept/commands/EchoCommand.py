from pyeasyaccept.commom.Configuration import Configuration

"""
This class provides the 'echo' command. The 'echo' command has the syntax: "echo [String]".
The 'echo' command prints the string in default output. 

@author: Gustavo Pereira
@author: Magno Jefferson
"""
from string import replace
class EchoCommand:

    def execute(self, script, parsedLine):
        """
        This method executes the 'echo' command 
        """        
        if(parsedLine.getNumberOfParameters() < 2):
            raise Exception("'echo' command syntax is: 'echo [anything]' ")
        
        resultAux = replace(str(parsedLine),"echo", "", 1)     
        result = str(resultAux).strip()
        
        print result
        
        return Configuration.ECHO_CODE
