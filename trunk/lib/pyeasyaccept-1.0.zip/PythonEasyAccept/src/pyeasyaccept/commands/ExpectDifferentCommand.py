from pyeasyaccept.result.Result import Result
from pyeasyaccept.commom.Configuration import Configuration
"""
It executes the given command (usually an external command) and checks
whether the returned object, when converted to a string, isn't equals to the string
given a first argument. If so, it returns a result with sucess message; otherwise, it returns 
a result with an error message describing the error that was detected.

The ExpectDiferent command syntax is: 'expectdifferent result apCommand arg1 arg2 ... argN'

@author: Gustavo Pereira
"""
class ExpectDifferentCommand:

    def execute(self, script, parsedLine):
        """
        This method executes the 'expectdifferent' command
        """        
        if(parsedLine.getNumberOfParameters() < 3):
            raise Exception("ExpectDiferent command syntax is: 'expectdifferent result apCommand arg1 arg2 ... argN'")
        
        notExpectedResult = parsedLine.getParameter(1)
        apCommand = parsedLine.getParameter(2)
        
        if(self.hasParameters(parsedLine)):
            parameters = parsedLine.subLine(3)
        else:
            parameters = []
        
        exception = None
        appMethodResult = None
        try:
            appMethodResult = script.execute(apCommand, parameters)
        except Exception, e:
            exception = e
            exceptionMsg = str(e)
            result = Result(parsedLine, Configuration.ERROR_CODE, exceptionMsg)
            result.addException(None, exceptionMsg)
            return result
            

        if(notExpectedResult != str(appMethodResult)):
            return Result(parsedLine, Configuration.SUCCESS_CODE, appMethodResult)
        
        
        result = Result(parsedLine, Configuration.ERROR_CODE, appMethodResult)
        result.addException(exception, "Expected anything diferent of " + str(notExpectedResult) + " But was: " + str(appMethodResult))
        return result
    
    """
    This method informs if a scipt line has parameters or not
    @param parsedLine: the scipt line
    """
    def hasParameters(self, parsedLine):
        return parsedLine.getNumberOfParameters() > 3