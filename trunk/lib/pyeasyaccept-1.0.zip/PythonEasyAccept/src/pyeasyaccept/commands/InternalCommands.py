from pyeasyaccept.commands.ExpectCommand import ExpectCommand
from pyeasyaccept.commands.ExpectErrorCommand import ExpectErrorCommand
from pyeasyaccept.commands.EchoCommand import EchoCommand
from pyeasyaccept.commands.ExpectDifferentCommand import ExpectDifferentCommand
from pyeasyaccept.commands.EqualFilesCommand import EqualFilesCommand

"""
This class contains all Python EasyAccept internal commands.
@author: Gustavo Pereira
"""
class InternalCommands:
    
    __commands = dict()
    

    def __init__(self):
        self.initCommands()
               
    def initCommands(self):
        """
        This method defines which comands are Python EasyAccept internal commands
        """   
        self.__commands["expect"] = ExpectCommand()
        self.__commands["expecterror"] = ExpectErrorCommand()
        self.__commands["echo"] = EchoCommand()
        self.__commands["expectdifferent"] = ExpectDifferentCommand()
        self.__commands["equalfiles"] = EqualFilesCommand()
     
    def containsCommand(self, command):
        """
        This method informs if a command received as parameter is a Python EasyAccept internal command
        """   
        return command in self.__commands
    
    def getInternalCommandInstance(self, command):
        """
        This method returns an instance of a specified command.
        """
        if(command in self.__commands):
            return self.__commands[command]
        
        return None