from pyeasyaccept.script.Script import Script
""" 
This class is the Python EasyAccept Runner. It is responsible for execute a
script file and returns the script file tests result.

@author: Gustavo Pereira
"""
class PythonEasyAcceptTestRunner:
    

    def __init__(self, facade, file):
        self.facade = facade
        self.file = file
         
    def runScript(self):
        """
        Run a specified test script
        @param file: the test script
        """   
        script = Script(self.facade, self.file)
        script.runScript()
        return script.getScriptResultManager()