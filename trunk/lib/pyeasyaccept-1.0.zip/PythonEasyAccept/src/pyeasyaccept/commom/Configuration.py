import os

""" 
This class is the Python EasyAccept configuration class. It's used for handling
the Python EA default configuration and to get dinamic configuration data, that depends
of the operational system.

@author: Gustavo Pereira
"""
class Configuration(object):
    
    FILE_SEPARATOR = os.sep
    WHITE_LINE_CODE = os.linesep
    ERROR_CODE = "FAILURE"
    SUCCESS_CODE = "PASSED"
    COMMENT_CODE = "#"
    ECHO_CODE = "echo"
    TEST_SCRIPTS_LOCATION = FILE_SEPARATOR + "resources"+ FILE_SEPARATOR + "scripts_for_test"
    
    __configSingleInstance = None
    
 
    def __init__(self):
        self.root = os.path.abspath("..\..")
    
    def getInstance():
        if(Configuration.__configSingleInstance == None):
            Configuration.__configSingleInstance = Configuration()
            return Configuration.__configSingleInstance
        
        return Configuration.__configSingleInstance
    
    getInstance = staticmethod(getInstance)    
        
    def getProjectRoot(self):
        """
        This method returns the project root path
        @return: the project root path
        """   
        return self.root