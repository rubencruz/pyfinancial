""" 
This class represents a script's test line.
@author: Gustavo Pereira
@author: Magno Jefferson
"""
class ParsedLine:
    

    def __init__(self):
        self.parameters = []

    def getNumberOfParameters(self):
        """
        This method returns the line's number of parameters
        @return: the line's number of parameters
        """
        return len(self.parameters)
    
    def getParameter(self, pos):
        """
        This method returns the parameter specified by the index received
        @return: the parameter specified by the index received
        """
        return self.parameters[pos]
    
    def getLineParametersList(self):
        """
        This method returns line's parameters list
        @return: the line's parameters list
        """
        return self.parameters
    
    def subLine(self, begin):
        """
        This method returns the line's sub-line especified by the initial index
        @return: the sub-line parameters 
        """
        return self.parameters.__getslice__(begin, len(self.parameters))
    
    def addParameter(self, parameter):
        """
        This method adds a parameter to the parsed line parameters list
        @param parameter: the parameter to be added
        """
        self.parameters.append(parameter)
    
    def __str__(self):
        """
        This method returns the parsed line's string representation
        """    
        out = ""  
        for p in self.parameters:
            out += p +" "
            
        return out
