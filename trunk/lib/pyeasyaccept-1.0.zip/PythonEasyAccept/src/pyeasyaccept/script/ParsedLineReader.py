from pyeasyaccept.script.ParsedLine import ParsedLine

"""
This class is responsible to read a new test line of a script.

@author: Gustavo Pereira
@author: Magno Jefferson
"""

class ParsedLineReader:
    
    parameters = []

    def __init__(self, scriptFile):
        self.fout = open(scriptFile, 'r')
        self.parsedLine = ParsedLine();
    

    def getParsedLine(self):
        """
        This method returns the parsed line
        @return: the parsed line
        """
        self.line = self.fout.readline()
        
        if(self.line == ""):
            return None
        
        self.parsedLine = self.generateParsedLine(self.line)
        return self.parsedLine
    
    def close(self):
        """
        This method closes the parsed line reader
        """
        self.fout.close()
    
    def getLine(self):
        """
        This method returns the last line readed
        @return: the current line
        """
        return self.line
    
    def generateParsedLine(self, line):
        """
        This method generates a ParsedLine object from the parsed line
        @param line: the line used to generate the parsed line
        """    
        parsedLine = ParsedLine()
        parameters = line.split()
        i = 0
        while(i < len(parameters)):
            
            param = parameters[i]
            if(str(param).__getitem__(0) == '"'):
                param, i = self.getString(parameters, i)
                
            parsedLine.addParameter(param)
            i += 1
            
        return parsedLine
  
    def removeFirstCharacter(self, string):
        """
        This method removes the first string character and return the resultant string
        @param string: the string to have the first character removed
        """
        return str(string).__getslice__(1,len(string))
  
    def removeLastCharacter(self, string):
        """
        This method removes the last string character and return the resultant string
        @param string: the string to have the last character removed
        """
        return str(string).__getslice__(0,len(string)-1)
  
    def getString(self,parameters, i):
        """
        This method mount a string parameter readed from the script file
        @param parameters: the parsed line parameters
        @param i: the current param index
        @return: the string mounted 
        """
        param = parameters[i]
        param = self.removeFirstCharacter(param)
        
        endString = False
        
        
        if(not(param[len(param)-1] == '"')):
            i +=1
            while(i < len(parameters) and not(endString)):
                currentParam = str(parameters[i])
                lastChar = currentParam.__getitem__(len(currentParam)-1)
                
                if( lastChar == '"' ):
                    endString = True;
                else:
                    i += 1
                    
                param += " " + currentParam
        
        param = self.removeLastCharacter(param)
        return param, i
