from pythoneasyaccept_test.TestFacade import TestFacade
from pyeasyaccept.script.Script import Script
from pyeasyaccept.commom.Configuration import Configuration
import unittest

"""
@author: Gustavo Pereira
"""
class ScriptTest(unittest.TestCase):
    
    configuration = Configuration()
    
    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.testFacade = TestFacade()  
        self.root = self.configuration.getProjectRoot()
        self.testFilesPaths = self.root + self.configuration.TEST_SCRIPTS_LOCATION
    
    def tearDown(self):
        pass
    
    def testAll(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script01.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(2, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(2, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(4, script.getScriptResultManager().getNumTests())
        
    def testComment(self):
         
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script02.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(1, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(0, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(1, script.getScriptResultManager().getNumTests())
        self.assertEquals(Configuration.SUCCESS_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())
        
    def testWhiteLine(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script03.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(1, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(1, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(2, script.getScriptResultManager().getNumTests())
        self.assertEquals(Configuration.SUCCESS_CODE, script.getScriptResultManager().getLineResult(5).getTestLineStatus())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(8).getTestLineStatus())
        
    def testMethodWithoutParameter(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script04.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(4, script.getScriptResultManager().getNumPassedTests())
        
        
    def testVerifyWrongResult(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script05.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(1, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())
        self.assertEquals(str(2), script.getScriptResultManager().getLineResult(2).getTestLineResult())
        
    def testExpectError_SUCESS(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script06.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals( "any exception", script.getScriptResultManager().getLineResult(1).getTestLineResult() )
        self.assertEquals( Configuration.SUCCESS_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus() )
        
    def testExpectError_FAILURE(self):
        
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script07.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals( "Exception message expected: 'other exception' But got: 'any exception'", script.getScriptResultManager().getLineResult(1).getErrorMessage() )
        self.assertEquals( Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus() )


if __name__ == '__main__':
    unittest.main()        