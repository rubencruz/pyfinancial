from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.PythonEasyAcceptFacade import PythonEasyAcceptFacade
from pythoneasyaccept_test.TestFacade import TestFacade
import unittest

"""
This class tests the PythonEasyAcceptFacade
@author: Gustavo Pereira
"""
class PythonEasyAcceptFacadeTest(unittest.TestCase):

    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.testFacade = TestFacade()
        self.configuration = Configuration()        
        self.root = self.configuration.getProjectRoot()
            
    def tearDown(self):
        pass
    
    """
    This test method tests the PythonEasyAccept API
    """
    def testAPI(self):
        
        scriptFile1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR +"script01.txt"
        scriptFile2 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR + "script02.txt"
        
        files = [scriptFile1, scriptFile2]
        facade = PythonEasyAcceptFacade(self.testFacade, files);
        facade.executeTests()

# each script tests
        
        self.assertEquals(2, facade.getScriptNumberOfPassedTests(scriptFile1))
        
        self.assertEquals(2, facade.getScriptNumberOfNotPassedTests(scriptFile1))
        
        self.assertEquals(4, facade.getScriptTotalNumberOfTests(scriptFile1))
        
        self.assertEquals( Configuration.ERROR_CODE, facade.getTestLineResult(scriptFile1, 2).getTestLineStatus() )
        
        self.assertEquals( Configuration.ERROR_CODE, facade.getTestLineResult(scriptFile1, 3).getTestLineStatus() )
        
        self.assertEquals( Configuration.SUCCESS_CODE, facade.getTestLineResult(scriptFile1, 4).getTestLineStatus() )
        
        self.assertEquals( Configuration.SUCCESS_CODE, facade.getTestLineResult(scriptFile1, 7).getTestLineStatus() )
        
        
# all scripts tests
        
        self.assertEquals(3, facade.getTotalNumberOfPassedTests())
        
        self.assertEquals(2, facade.getTotalNumberOfNotPassedTests())
        
        self.assertEquals(5, facade.getTotalNumberOfTests())
        
       
        
if __name__ == '__main__':
    unittest.main()