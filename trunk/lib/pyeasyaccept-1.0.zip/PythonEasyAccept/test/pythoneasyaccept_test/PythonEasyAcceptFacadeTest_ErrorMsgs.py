from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.PythonEasyAcceptFacade import PythonEasyAcceptFacade
from pythoneasyaccept_test.TestFacade import TestFacade
import unittest

"""
This class tests the PythonEasyAcceptFacade's error messages and others situations.
@author: Gustavo Pereira
"""
class PythonEasyAcceptFacadeTest_ErrorMsgs(unittest.TestCase):
    
    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.testFacade = TestFacade()
        self.configuration = Configuration()        
        self.root = self.configuration.getProjectRoot()
        self.inexistentScriptFile = "inexistentScriptFile"
        self.scriptFile1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR +"script01.txt"
        self.scriptFile2 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR + "script02.txt"

    
    def tearDown(self):
        pass
    
    def testInexistentScriptFile(self):
                
        files = [self.scriptFile1, self.scriptFile2]
        facade = PythonEasyAcceptFacade(self.testFacade, files);
        facade.executeTests()
        
        self.assertEquals(None, facade.getTestLineResult(self.scriptFile1, 1001))
        
        self.assertEquals(None, facade.getScriptCompleteResults(self.inexistentScriptFile))
        
        self.assertEquals(None, facade.getScriptSummarizedResults(self.inexistentScriptFile))
        
        self.assertEquals(None, facade.getScriptResults(self.inexistentScriptFile))
        
        self.assertEquals(None, facade.getScriptNumberOfPassedTests(self.inexistentScriptFile))
        
        self.assertEquals(None, facade.getScriptNumberOfNotPassedTests(self.inexistentScriptFile))
        
        self.assertEquals(None, facade.getScriptTotalNumberOfTests(self.inexistentScriptFile))
        
    def testInvalidScriptPaths(self):
        
        
        files = [self.inexistentScriptFile, self.scriptFile2]
        facade = PythonEasyAcceptFacade(self.testFacade, files);
        
        expectedErrorMessage = "Can not execute tests. Inexistent file(s): [inexistentScriptFile]"
        
        try:
            facade.executeTests()
        except Exception, e:
            self.assertEquals(expectedErrorMessage, str(e))


    def testAnyTestScriptReceived(self):
                
        files = []
        expectedErrorMessage = "There isn't any test script to be executed."
        
        try:
            PythonEasyAcceptFacade(self.testFacade, files);
        except Exception, e:
            self.assertEquals(expectedErrorMessage, str(e))
            
    def testNoneFacade(self):
          
        files = [self.scriptFile1]
        expectedErrorMessage = "'None' is not a valid Facade."
        
        try:
            PythonEasyAcceptFacade(None, files);
        except Exception, e:
            self.assertEquals(expectedErrorMessage, str(e))

        
        
if __name__ == '__main__':
    unittest.main() 