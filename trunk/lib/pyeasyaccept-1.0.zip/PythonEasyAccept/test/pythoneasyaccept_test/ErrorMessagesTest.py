from pyeasyaccept.commom.Configuration import Configuration
from pythoneasyaccept_test.TestFacade import TestFacade
from pyeasyaccept.script.Script import Script
import unittest

"""
This class contains several error messages tests.
@author: Gustavo Pereira
"""
class ErrorMessagesTest(unittest.TestCase):

    configuration = Configuration()
    
    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.testFacade = TestFacade()        
        self.root = self.configuration.getProjectRoot()
        self.testFilesPaths = self.root + self.configuration.TEST_SCRIPTS_LOCATION
    
    def tearDown(self):
        pass
    
    def testUnknownApplicationCommand(self):
         
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script08.txt"
        script = Script(facade, file)
        script.runScript()
        
        self.assertEquals(0, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(4, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(4, script.getScriptResultManager().getNumTests())
        
        exceptionMessage1 = "Unknown command: unknownCommand"
        
        self.assertEquals(exceptionMessage1, script.getScriptResultManager().getLineResult(1).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus())
        
        exceptionMessage2 = "Exception message expected: '3' But got: 'Unknown command: otherUnknownCommand'"
        
        self.assertEquals(exceptionMessage2, script.getScriptResultManager().getLineResult(2).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())
        
        exceptionMessage3 = "Unknown command: thirdUnknownCommand"
        
        self.assertEquals(exceptionMessage3, script.getScriptResultManager().getLineResult(3).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(3).getTestLineStatus())
        
        exceptionMessage4 = "Unknown command: fourthUnknownCommand"
        
        self.assertEquals(exceptionMessage4, script.getScriptResultManager().getLineResult(4).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(4).getTestLineStatus())



    def testUnknownPythonEasyAcceptCommand(self):
         
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script09.txt"
        script = Script(facade, file)
        script.runScript()

        self.assertEquals(0, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(2, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(2, script.getScriptResultManager().getNumTests())
        
        exceptionMessage1 = "Unknown command: expec"
        
        self.assertEquals(exceptionMessage1, script.getScriptResultManager().getLineResult(1).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus())
        
        exceptionMessage2 = "Unknown command: expecerror"
        
        self.assertEquals(exceptionMessage2, script.getScriptResultManager().getLineResult(2).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())

        
        
    def testUnknownApplicationCommand_WrongParameters(self):
         
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script10.txt"
        script = Script(facade, file)
        script.runScript()

        self.assertEquals(0, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(5, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(5, script.getScriptResultManager().getNumTests())
        
        exceptionMessage1 = "Incorrect parameters for application command 'div'. Parameters received: ['6']"
        
        self.assertEquals(exceptionMessage1, script.getScriptResultManager().getLineResult(1).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus())
        
        exceptionMessage2 = "Incorrect parameters for application command 'returnString'. Parameters received: ['abc']"
        
        self.assertEquals(exceptionMessage2, script.getScriptResultManager().getLineResult(2).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())
        
        exceptionMessage3 = "Incorrect parameters for application command 'concat'. Parameters received: []"
        
        self.assertEquals(exceptionMessage3, script.getScriptResultManager().getLineResult(3).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(3).getTestLineStatus())
        
        exceptionMessage4 = "Exception message expected: '3' But got: 'Incorrect parameters for application command 'div'. Parameters received: ['6']'"
        
        self.assertEquals(exceptionMessage4, script.getScriptResultManager().getLineResult(4).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(4).getTestLineStatus())
        
        exceptionMessage5 = "Incorrect parameters for application command 'div'. Parameters received: ['6']"
        
        self.assertEquals(exceptionMessage5, script.getScriptResultManager().getLineResult(5).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(5).getTestLineStatus())



    def testPythonEasyAcceptCommands_WrongNumberOfParameters(self):
         
        facade = TestFacade()
        file = self.testFilesPaths + self.FILE_SEPARATOR + "script11.txt"
        script = Script(facade, file)
        script.runScript()

        self.assertEquals(0, script.getScriptResultManager().getNumPassedTests())
        self.assertEquals(3, script.getScriptResultManager().getNumNotPassedTests())
        self.assertEquals(3, script.getScriptResultManager().getNumTests())
        
        exceptionMessage1 = "Expect command syntax is: 'expect result applicationCommand arg1 arg2 ... argN'"
        
        self.assertEquals(exceptionMessage1, script.getScriptResultManager().getLineResult(1).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(1).getTestLineStatus())
        
        exceptionMessage2 = "ExpectError command syntax is: 'errorExpected expectedError apCommand arg1 arg2 ... argN'"
        
        self.assertEquals(exceptionMessage2, script.getScriptResultManager().getLineResult(2).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(2).getTestLineStatus())
        
        exceptionMessage3 = "ExpectDiferent command syntax is: 'expectdifferent result apCommand arg1 arg2 ... argN'"
        
        self.assertEquals(exceptionMessage3, script.getScriptResultManager().getLineResult(3).getErrorMessage())
        self.assertEquals(Configuration.ERROR_CODE, script.getScriptResultManager().getLineResult(3).getTestLineStatus())





if __name__ == '__main__':
    unittest.main()