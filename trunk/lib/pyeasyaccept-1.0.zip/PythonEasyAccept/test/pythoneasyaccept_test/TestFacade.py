"""
This class is a python application facade example. This class will be used by default in all
Python EasyAccept acceptance tests and others.
 
@author: Gustavo Pereira
"""
class TestFacade:
    

    def __init__(self):
        self.value = None
    

    def concat(self, a, b):
        """
        This method concatenate two strings
        @param a: the first string
        @param b: the secand string
        @return: the resultant string
        """
        return a+b;
    

    def sum(self, a, b):
        """
        This method sum two integers
        @param a: the first integer
        @param b: the secand integer 
        @return: the sum
        """
        return int(a) + int(b);
    

    def sub(self, a, b):
        """
        This method subtract two integers
        @param a: the first integer
        @param b: the secand integer 
        @return: the subtraction
        """
        return int(a) - int(b);
    

    def div(self, a, b):
        """
        This method devide two integers
        @param a: the first integer
        @param b: the secand integer 
        @return: the division
        """
        return int(a)/int(b);
    

    def returnString(self):
        """
        @return the string "string"
        """
        return "string";
    

    def throwsException(self):
        """
        This method throws an Exception with the message: "any exception"
        """
        raise Exception, "any exception"
    

    def setAtribute(self, value):
        """
        This method sets an atribute value
        @param value: the parameter value 
        """
        self.value = value
    
  
    def getAtribute(self):
        """
        This method gets an atribute value
        @return: the parameter value 
        """  
        return self.value
    

    def doNothing(self):
        """
        This method does nothing
        """
        pass
