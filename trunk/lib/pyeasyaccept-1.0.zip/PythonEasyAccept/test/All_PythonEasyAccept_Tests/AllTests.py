import unittest
""" 
@author: Gustavo Pereira
"""
from unittest import TestSuite
from commands_test.EchoCommandTest import EchoCommandTest
from commands_test.EqualFilesCommandTest import EqualFilesCommandTest
from commands_test.ExpectCommandTest import ExpectCommandTest
from commands_test.ExpectDifferentCommandTest import ExpectDifferentCommandTest
from commands_test.ExpectErrorCommandTest import ExpectErrorCommandTest
from pythoneasyaccept_test.ErrorMessagesTest import ErrorMessagesTest
from pythoneasyaccept_test.PythonEasyAcceptFacadeTest import PythonEasyAcceptFacadeTest
from script_test.ScriptTest import ScriptTest
from pythoneasyaccept_test.PythonEasyAcceptFacadeTest_ErrorMsgs import PythonEasyAcceptFacadeTest_ErrorMsgs

class AllTests(unittest.TestCase):

    def runSuite(self):
        suite = TestSuite()
        # commands
        suite.addTest(EchoCommandTest())
        suite.addTest(EqualFilesCommandTest())
        suite.addTest(ExpectCommandTest())
        suite.addTest(ExpectDifferentCommandTest())
        suite.addTest(ExpectErrorCommandTest())
        # facade and error messages
        suite.addTest(ErrorMessagesTest())
        suite.addTest(PythonEasyAcceptFacadeTest())
        suite.addTest(PythonEasyAcceptFacadeTest_ErrorMsgs())
        # script
        suite.addTest(ScriptTest())
        
if __name__ == '__main__':
    unittest.main() 
        
