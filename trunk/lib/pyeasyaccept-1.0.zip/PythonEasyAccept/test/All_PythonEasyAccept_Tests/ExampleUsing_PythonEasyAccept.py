from pythoneasyaccept_test.TestFacade import TestFacade
from pyeasyaccept.PythonEasyAcceptFacade import PythonEasyAcceptFacade
from pyeasyaccept.commom.Configuration import Configuration
import unittest

"""
This class is an example about how to use Python EasyAccept.
"""
class ExampleUsing_PythonEasyAccept(unittest.TestCase):

    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.testFacade = TestFacade()
        self.configuration = Configuration()        
        self.root = self.configuration.getProjectRoot()
    
    def tearDown(self):
        pass

    """
    This test method build and execute the tests and get its results  
    """
    def test(self):
        scriptFile2 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR + "script02.txt"
        scriptFile1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + self.FILE_SEPARATOR + "script01.txt"

        facade = TestFacade()
        files = [scriptFile1, scriptFile2]
        peaFacade = PythonEasyAcceptFacade(facade, files)
        peaFacade.executeTests()
        
#        print peaFacade.getScriptSummarizedResults(scriptFile1)
        print peaFacade.getCompleteResults()
#        print peaFacade.getSummarizedResults()

    
if __name__ == '__main__':
    unittest.main()    