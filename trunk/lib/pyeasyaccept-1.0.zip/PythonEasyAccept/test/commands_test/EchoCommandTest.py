from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.commands.EchoCommand import EchoCommand
from pyeasyaccept.script.ParsedLineReader import ParsedLineReader
import unittest

"""
This class tests the 'echo' command
@author: Magno Jefferson
"""
class EchoCommandTest(unittest.TestCase):
    
    configuration = Configuration.getInstance()
    
    """
    This method sets initial information
    """
    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR          
        self.root = self.configuration.getProjectRoot()
        
    """
    This method tear down informations
    """
    def tearDown(self):
        pass

    """
    This method runs the tests
    """
    def testEchoCommand(self):
        testEchoCommand1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\TestEcho1.txt"
         
        parsedLineReader = ParsedLineReader(testEchoCommand1)
        parsedLine = parsedLineReader.getParsedLine()
        
        echoCommand = EchoCommand();
        
        result = echoCommand.execute(testEchoCommand1, parsedLine)
        
        self.assertEquals(Configuration.ECHO_CODE, result)
        
    
if __name__ == '__main__':
    unittest.main() 