from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.PythonEasyAcceptFacade import PythonEasyAcceptFacade
from pythoneasyaccept_test.TestFacade import TestFacade
import unittest

"""
This class tests the 'expecterror' command
@author: Magno Jefferson
@author: Gustavo Pereira
"""
class ExpectErrorCommandTest(unittest.TestCase):
    
    """
    This method sets initial information
    """
    def setUp(self):
        self.testFacade = TestFacade()
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.configuration = Configuration()        
        self.root = self.configuration.getProjectRoot()
        
    """
    This method tear down informations
    """
    def tearDown(self):
        pass

    """
    This method runs the tests
    """
    def testExpectErrorCommand(self):
        testExpectErrorCommand1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\TestExpectError1.txt"
        
        files = [testExpectErrorCommand1]
        facade = PythonEasyAcceptFacade(self.testFacade, files);
        facade.executeTests()
         
        self.assertEquals(1, facade.getScriptNumberOfPassedTests(testExpectErrorCommand1))
        
        self.assertEquals(2, facade.getScriptNumberOfNotPassedTests(testExpectErrorCommand1))
        
        self.assertEquals(3, facade.getScriptTotalNumberOfTests(testExpectErrorCommand1))
    
if __name__ == '__main__':
    unittest.main() 