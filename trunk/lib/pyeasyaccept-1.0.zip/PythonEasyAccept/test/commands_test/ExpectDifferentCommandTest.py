from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.PythonEasyAcceptFacade import PythonEasyAcceptFacade
from pythoneasyaccept_test.TestFacade import TestFacade
import unittest

"""
This class tests the 'expectdifferent' command
@author: Magno Jefferson
"""
class ExpectDifferentCommandTest(unittest.TestCase):
    
    """
    This method sets initial information
    """
    def setUp(self):
        self.testFacade = TestFacade()
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR  
        self.configuration = Configuration()        
        self.root = self.configuration.getProjectRoot()
        
    """
    This method tear down informations
    """
    def tearDown(self):
        pass

    """
    This method runs the tests
    """
    def testExpectDifferentCommand(self):
        testExpectDifferentCommand1 = self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\TestExpectDifferent1.txt"
         
        files = [testExpectDifferentCommand1]
        facade = PythonEasyAcceptFacade(self.testFacade, files);
        facade.executeTests()
         
        self.assertEquals(2, facade.getScriptNumberOfPassedTests(testExpectDifferentCommand1))
        
        self.assertEquals(1, facade.getScriptNumberOfNotPassedTests(testExpectDifferentCommand1))
        
        self.assertEquals(3, facade.getScriptTotalNumberOfTests(testExpectDifferentCommand1))
    
if __name__ == '__main__':
    unittest.main() 