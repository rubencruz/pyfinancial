from pyeasyaccept.commom.Configuration import Configuration
from pyeasyaccept.commands.EqualFilesCommand import EqualFilesCommand
from pyeasyaccept.script.ParsedLineReader import ParsedLineReader

import unittest
"""
This class tests 'expecterror' command
@author: Magno Jefferson
"""
class EqualFilesCommandTest(unittest.TestCase):
    
    configuration = Configuration()
    
    """
    This method sets initial information
    """
    def setUp(self):
        self.FILE_SEPARATOR = Configuration.FILE_SEPARATOR         
        self.root = self.configuration.getProjectRoot()
        
        self.scriptBeenCreatedPath = self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\TestEqualFiles1.txt"
        self.scriptPathToWrite =  '"' + self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\script01.txt" + '"'
        self.scriptPathToWrite2 =  '"' + self.root + self.configuration.TEST_SCRIPTS_LOCATION + "\script02.txt" + '"'   
        self.scriptFile = open(self.scriptBeenCreatedPath, "w")
    
    """
    This method tear down informations
    """  
    def tearDown(self):
        # deletar arquivo
        #del(self.scriptFile)
        pass
     
    """
    This method runs the test scenery 1
    """  
    def testEqualFiles1(self):
        
        completeStringToWrite = "equalfiles " + self.scriptPathToWrite + " " + self.scriptPathToWrite
        
        self.scriptFile.write(completeStringToWrite)
        self.scriptFile.close()
        
        #The file was already created and now we have a created file path
        createdScriptPath = self.scriptBeenCreatedPath
        
        parsedLineReader = ParsedLineReader(createdScriptPath)
        
        parsedLine = parsedLineReader.getParsedLine()
        
        eqfCommand = EqualFilesCommand();
        
        result = eqfCommand.execute(self.scriptBeenCreatedPath, parsedLine)
        
        self.assertEquals(Configuration.SUCCESS_CODE, result.getTestLineStatus())


    """
    This method runs the test scenery 2
    """ 
    def testEqualFiles2(self):
        
        completeStringToWrite = "equalfiles " + self.scriptPathToWrite + " " + self.scriptPathToWrite2
        
        self.scriptFile.write(completeStringToWrite)
        self.scriptFile.close()
        
        #The file was already created and now we have a created file path
        createdScriptPath = self.scriptBeenCreatedPath
        
        parsedLineReader = ParsedLineReader(createdScriptPath)
        
        parsedLine = parsedLineReader.getParsedLine()
        
        eqfCommand = EqualFilesCommand();
        
        result = eqfCommand.execute(self.scriptBeenCreatedPath, parsedLine)
        
        self.assertEquals(Configuration.ERROR_CODE, result.getTestLineStatus())
        
        expectedErrorMessage  = "The files are different at line number 1. The expected line content is: # aritmetics operations methods"
        
        self.assertEquals(expectedErrorMessage, result.getErrorMessage())

if __name__ == '__main__':
    unittest.main()            
        