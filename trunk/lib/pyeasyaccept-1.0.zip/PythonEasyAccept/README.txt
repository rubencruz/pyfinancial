Executes the script "setup.py" from this directory (PythonEasyAccept), following the syntax: "python setup.py install".

For more information about the use of Python EasyAccept, see the project home page (www.pyeasyaccept.org) 

and see the user manual and the tutorial.