from distutils.core import setup
setup(name='Python EasyAccept',
      version='1.0',
      description = "Python EasyAccept: A tool to create and run acceptance tests.",
      author = "Gustavo Pereira de Farias Lima",
      author_email = "gugafarias@gmail.com",
      url = "http://www.pyeasyaccept.org",
      license ="GNU General Public License (GPL)",
      platform = "Platform independent",
      package_dir={"":"src"},
      packages=['pyeasyaccept', 'pyeasyaccept.commands', 'pyeasyaccept.commom', 'pyeasyaccept.result', 'pyeasyaccept.script']
      )